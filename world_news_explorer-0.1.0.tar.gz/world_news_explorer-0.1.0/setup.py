# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['world_news_explorer', 'world_news_explorer.scraper']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.4.40,<2.0.0',
 'goslate>=1.5.4,<2.0.0',
 'lxml>=4.9.1,<5.0.0',
 'pandas>=1.4.4,<2.0.0',
 'psycopg2>=2.9.3,<3.0.0',
 'requests>=2.28.1,<3.0.0']

setup_kwargs = {
    'name': 'world-news-explorer',
    'version': '0.1.0',
    'description': '',
    'long_description': "# world_news_explorer\nIt's difficult to keep track of what's going on in the world.\n\nBut let's aim to collect one headline from one newspaper in each country in the world to begin with, translated into english.\n\nAnd then we'll expose that online.\n\nIt's a start at least\n",
    'author': 'victor wiklund',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/vicwik-gyg/world_news_explorer',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
