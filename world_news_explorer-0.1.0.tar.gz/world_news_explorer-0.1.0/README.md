# world_news_explorer
It's difficult to keep track of what's going on in the world.

But let's aim to collect one headline from one newspaper in each country in the world to begin with, translated into english.

And then we'll expose that online.

It's a start at least
