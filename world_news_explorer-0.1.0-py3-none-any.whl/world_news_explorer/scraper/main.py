import argparse

import database_interactions
import scraper
import translator
from base_logger import lg
from config import websites_to_scrape


def setup_argument_parser():
    # Define the parser and default arguments
    parser = argparse.ArgumentParser(description='A program that scrapes news from websites')
    parser.add_argument("--xpath",
                        help="If set, tries to scrape content at specified xpath",
                        default='//*')
    parser.add_argument("-n", "--newspaper",
                        help="If set, tries to find the website configuration in the config file and attempts the scrape")

    parser.add_argument("-d", "--debug",
                        action='store_true',
                        help="If set, print additional debug info")
    return parser

parser = setup_argument_parser()
args = vars(parser.parse_args())
if args['debug']:
    lg.getLogger().setLevel(lg.DEBUG)
elif args['newspaper']:
    scraper.scrape_single_website(newspaper_name=args['newspaper'], website_configs=websites_to_scrape)
else:
    lg.info("Beginning scrape")
    scraper.scrape_all_websites(websites_to_scrape)
    lg.info("Beginning translation")
    translator.translate()
    lg.info("Uploading to database")
    database_interactions.upload_into_raw_news()
    database_interactions.upload_into_translated_news()
    lg.info("Done")
